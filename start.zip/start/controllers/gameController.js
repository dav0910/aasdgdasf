const Model = require('../models/gameModel');

function get_turno(){
    return Model.get_turno();
}

function add_giocatore(uuid){
    console.log("2");
    res = Model.add_giocatore(uuid);
    if(res === -1){
        return -1;
    }
    else{
        return 0;
    }
}

function rimuovi_giocatore(uuid){
    Model.rimuovi_giocatore(uuid);
}

function cambia_turno(uuid){
    res = Model.cambia_turno(uuid);
    if(res === -1){
        return -1;
    }
    else{
        return 0;
    }
}

module.exports ={
    cambia_turno,
    get_turno,
    add_giocatore,
    rimuovi_giocatore
}