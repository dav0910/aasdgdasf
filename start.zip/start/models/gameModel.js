//turno = ""; //UUID del computer a cui tocca

let giocatori = []; //lista degli UUID

function cambia_turno(uuid){
    if(uuid == giocatori[0]){
        giocatori.push(giocatori[0])
        giocatori.splice(0,1);
        return 0;
    }
    else{
        return -1;
    }
}

function get_turno(){
    return giocatori[0];
}

function add_giocatore(uuid){
    console.log("3");
    if(giocatori.length >= 2){
        return -1;
    }
    giocatori.push(uuid);
    console.log(giocatori);
    return 0;
}

function get_giocatore(pos){
    try{
        return giocatori[pos]
    }
    catch{
        return -1;
    }
}
       
function rimuovi_giocatore(uuid){
    for(i = 0; i<giocatori.length;i++){
        if(giocatori[i] == uuid){
            giocatori.splice(i,1);
            return 0;
        }
    }
    return -1;
}

module.exports ={
    cambia_turno,
    get_turno,
    add_giocatore,
    get_giocatore,
    rimuovi_giocatore
}